***************************
Moved: Verification options
***************************

.. meta::
    :http-equiv=refresh: 0; ../api/verification.html

This page has been moved to :doc:`../api/verification`.
