Acknowledge PyAstronomy
=========================

If you make use of PyAstronomy and it has (hopefully) helped you in your work,
we would be thankful if you acknowledge it by including a sentence like "This
work made use of PyAstronomy." in your acknowledgments and a link
to PyAstronomy (https://github.com/sczesla/PyAstronomy) given, e.g., as
a footnote.

The PyA group
 
