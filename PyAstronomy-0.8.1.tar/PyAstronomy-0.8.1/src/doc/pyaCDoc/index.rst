PyAstronomy core (pyaC)
=========================

The **pyaC** package (pyaCore) is the place to collect functionality commonly required among PyAstronomy's subpackages.

Moreover, pyaC's documentation is the place were general guide lines for PyAstronomy are formulated. 

Contents:

.. toctree::
   :maxdepth: 1
   
   versioning.rst
   pyaErrorsDoc/index.rst
   IDLPorting.rst
   pyaPermanentDoc/index.rst
   needfulThings.rst
   