Rossiter-McLaughlin model class
====================================

The class *RcmL* implements the
analytical model presented by *Ohta et al. 2005*.

.. currentmodule:: PyAstronomy.modelSuite
.. autoclass:: RmcL
   :members:

