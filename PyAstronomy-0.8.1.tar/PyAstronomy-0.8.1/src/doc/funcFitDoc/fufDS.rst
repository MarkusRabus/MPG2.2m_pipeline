FuncFit data set
==================

The funcFit data set encapsulates the data to be
fitted.

.. currentmodule:: PyAstronomy.funcFit
.. autoclass:: FufDS
   :members: