Constructing n-dimensional coordinate mapping
==============================================

If you have n-dimensional input data such as an image,
funcFit needs an appropriate coordinate mapping.

.. currentmodule:: PyAstronomy.funcFit
.. autofunction::  coordinateGrid