Planck's radiation law
=======================

.. currentModule:: PyAstronomy.pyasl

.. autofunction:: planck