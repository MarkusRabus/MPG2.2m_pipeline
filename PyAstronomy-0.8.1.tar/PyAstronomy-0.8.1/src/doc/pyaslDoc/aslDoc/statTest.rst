F-test
======================

.. currentmodule:: PyAstronomy.pyasl
.. autofunction:: ftest