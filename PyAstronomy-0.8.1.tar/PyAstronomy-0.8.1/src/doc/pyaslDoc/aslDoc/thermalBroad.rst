Thermal broadening
====================

.. currentModule:: PyAstronomy.pyasl
.. autofunction:: thermalBroadeningWidth