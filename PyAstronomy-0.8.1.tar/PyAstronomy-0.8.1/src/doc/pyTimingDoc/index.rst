The (py)Timing module
========================

The *pyTiming* module is a collection of submodules \
implementing algorithms for timing analysis such as \
Lomb-Scargle periodograms.


**Contents**:

.. toctree::
    :maxdepth: 1

    pyPeriodDoc/pyPeriod.rst
    pyPDMDoc/pdm.rst
