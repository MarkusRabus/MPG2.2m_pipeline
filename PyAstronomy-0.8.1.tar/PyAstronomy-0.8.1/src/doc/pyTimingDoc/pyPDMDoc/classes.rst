Scanner and PDM class
=========================

The *Scanner* and *PyPDM* class are used to carry out the PDM analysis.

The Scanner class
------------------------------------------

.. currentmodule:: PyAstronomy.pyTiming.pyPDM
.. autoclass:: Scanner
   :members:

The PyPDM class
------------------------------------------

.. autoclass:: PyPDM
   :members:
