from PyAstronomy.pyaC import ImportCheck

ic = ImportCheck(["Tkinter", "matplotlib"], required=["Tkinter", "matplotlib"])

from pyaPicker import Picker
from ffmodelExplorer import FFModelExplorer, FFModelExplorerList, FFModelPlotFit, ffmodelExplorer
from continuumFinder import ContinuumInteractive
from interactiveGV import IAGVFit