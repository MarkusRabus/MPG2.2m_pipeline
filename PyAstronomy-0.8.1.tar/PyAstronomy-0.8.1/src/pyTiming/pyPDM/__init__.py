from PyAstronomy.pyaC import ImportCheck

ImportCheck(["numpy"], required=["numpy"]) 

from pdm import *